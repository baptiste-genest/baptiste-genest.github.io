// leave at least 2 line with only a star on it below, or doc generation fails
/**
 *
 *
 * Same goal as custom.js, but loaded in a different order, before the main.js script is executed
 *
 *
 * @module IPython
 * @namespace IPython
 * @class custompreloadjs
 * @static
 */

